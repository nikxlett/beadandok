#ifndef STOCKFISHWRAPPER_H
#define STOCKFISHWRAPPER_H

#include <QObject>
#include <QProcess>

class StockfishWrapper : public QObject
{
    Q_OBJECT

public:
    StockfishWrapper(QObject *parent = nullptr);
    ~StockfishWrapper();

    void startEngine();
    void sendCommand(const QString &command);

signals:
    void engineResponse(const QString &response);

private slots:
    void readEngineOutput();

private:
    QProcess stockfishProcess;
};
#endif // STOCKFISHWRAPPER_H
