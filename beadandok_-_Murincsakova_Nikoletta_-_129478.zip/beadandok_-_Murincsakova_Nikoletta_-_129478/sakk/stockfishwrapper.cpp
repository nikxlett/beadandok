// stockfishwrapper.cpp
#include "stockfishwrapper.h"

StockfishWrapper::StockfishWrapper(QObject *parent)
    : QObject(parent) {
    connect(&stockfishProcess, &QProcess::readyReadStandardOutput, this, &StockfishWrapper::readEngineOutput);
}

StockfishWrapper::~StockfishWrapper() {
    stockfishProcess.kill();
    stockfishProcess.waitForFinished();
}

void StockfishWrapper::startEngine() {
    stockfishProcess.start(":/stockfish/stockfish-windows-x86-64-avx2.exe"); // Replace with the actual path
    stockfishProcess.waitForStarted();
}

void StockfishWrapper::sendCommand(const QString &command) {
    stockfishProcess.write((command + "\n").toUtf8());
    stockfishProcess.waitForBytesWritten();
}

void StockfishWrapper::readEngineOutput() {
    QByteArray output = stockfishProcess.readAllStandardOutput();
    QString response = QString::fromUtf8(output).trimmed();
    emit engineResponse(response);
}
