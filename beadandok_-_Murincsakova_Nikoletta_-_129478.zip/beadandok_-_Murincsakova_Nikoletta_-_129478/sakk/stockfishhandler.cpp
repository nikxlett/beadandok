#include "stockfishhandler.h"
#include "qcoreapplication.h"
#include "qdir.h"
#include <chessboardwidget.h>

StockfishHandler::StockfishHandler(QObject *parent)
    : QObject(parent){
    connect(&stockfishProcess, &QProcess::readyReadStandardOutput, this, &StockfishHandler::processOutput);
    connect(&stockfishProcess, &QProcess::readyReadStandardError, this, &StockfishHandler::processStandardError);
}

void StockfishHandler::startEngine() {
    // stockfishProcess.start("D:\\Programming\\Qt\\_Projects\\sakk\\stockfish\\stockfish.exe");
    // stockfishProcess.start("../stockfish/stockfish.exe"); // Ez nem jó!
    stockfishProcess.start(QCoreApplication::instance()->applicationDirPath() + "/../../sakk/stockfish/stockfish.exe");
}

void StockfishHandler::parancsKuldes(const QString &command) {
    qDebug() << "Look!! I got a stockfish command: " << command;
    stockfishProcess.write((command + "\n").toUtf8());
}

void StockfishHandler::processOutput() {
    QByteArray output = stockfishProcess.readAllStandardOutput();
    qDebug() << "Stockfish Output:" << output;

    QStringList lines = QString(output).split("\n", Qt::SkipEmptyParts);
    QStringList legalMoves;

    QString bestMove;

    for (const QString &line : lines) {
        if (line.startsWith("bestmove")) {
            QStringList reszek = line.split(" ");
            if (reszek.size() >= 2) {
                bestMove = reszek.at(1);
                break;
            }
        }
    }

    // qDebug() << "Best Move:" << bestMove;
    // qDebug() << "check parent";
    if (parent()) {
        // qDebug() << "parent is not null";
        ChessboardWidget *parentObject = qobject_cast<ChessboardWidget*>(parent());
        if (parentObject) {
            // qDebug() << "parent handlestock call";
            if(bestMove.size() > 0){
                // qDebug() << "bestmove: " << bestMove;;
                parentObject->handleStockFishMove(bestMove);
            }
        }
    }
    // parent()->h
    // parent()->handleStockFishMove(bestMove.split(" ")[1]);
}

void StockfishHandler::processStandardError()
{
    QByteArray errorOutput = stockfishProcess.readAllStandardError();
    qWarning() << "Stockfish Error:" << errorOutput;
}
