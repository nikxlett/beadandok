#ifndef STOCKFISHHANDLER_H
#define STOCKFISHHANDLER_H

#include <QObject>
#include <QProcess>

class StockfishHandler : public QObject
{
    Q_OBJECT

public:
    StockfishHandler(QObject *parent = nullptr);
    void startEngine();
    void parancsKuldes(const QString &command);

private slots:
    void processOutput();
    void processStandardError();

private:
    QProcess stockfishProcess;
};

#endif // STOCKFISHHANDLER_H
