#include "mainwindow.h"
#include "ui_mainwindow.h"
#include <QPushButton>
#include <QPlainTextEdit>
#include <QMessageBox>
#include <QCoreApplication>
#include <QJSEngine>
#include <QJSValue>
#include <QGraphicsOpacityEffect>

MainWindow::MainWindow(QWidget *parent)
    : QMainWindow(parent)
    , ui(new Ui::MainWindow)
{
    ui->setupUi(this);
    ui->memoria->hide();

    ui->pushButton_egyenlo->setDisabled(true);
    ui->pushButton_plusz->setDisabled(true);
    //ui->pushButton_minusz->setDisabled(true);
    ui->pushButton_szorzas->setDisabled(true);
    ui->pushButton_osztas->setDisabled(true);
    ui->pushButton_egesz->setDisabled(true);
    ui->pushButton_torolegyet->setDisabled(true);

    QString ujra = "nem";

    connect(ui->pushButton_0, &QPushButton::clicked, this, &MainWindow::onButtonClick_0);
    connect(ui->pushButton_1, &QPushButton::clicked, this, &MainWindow::onButtonClick_1);
    connect(ui->pushButton_2, &QPushButton::clicked, this, &MainWindow::onButtonClick_2);
    connect(ui->pushButton_3, &QPushButton::clicked, this, &MainWindow::onButtonClick_3);
    connect(ui->pushButton_4, &QPushButton::clicked, this, &MainWindow::onButtonClick_4);
    connect(ui->pushButton_5, &QPushButton::clicked, this, &MainWindow::onButtonClick_5);
    connect(ui->pushButton_6, &QPushButton::clicked, this, &MainWindow::onButtonClick_6);
    connect(ui->pushButton_7, &QPushButton::clicked, this, &MainWindow::onButtonClick_7);
    connect(ui->pushButton_8, &QPushButton::clicked, this, &MainWindow::onButtonClick_8);
    connect(ui->pushButton_9, &QPushButton::clicked, this, &MainWindow::onButtonClick_9);

    connect(ui->pushButton_egesz, &QPushButton::clicked, this, &MainWindow::onButtonClick_egesz);
    connect(ui->pushButton_egyenlo, &QPushButton::clicked, this, &MainWindow::onButtonClick_egyenlo);
    connect(ui->pushButton_plusz, &QPushButton::clicked, this, &MainWindow::onButtonClick_plusz);
    connect(ui->pushButton_minusz, &QPushButton::clicked, this, &MainWindow::onButtonClick_minusz);
    connect(ui->pushButton_szorzas, &QPushButton::clicked, this, &MainWindow::onButtonClick_szorzas);
    connect(ui->pushButton_osztas, &QPushButton::clicked, this, &MainWindow::onButtonClick_osztas);
    connect(ui->pushButton_torolegyet, &QPushButton::clicked, this, &MainWindow::onButtonClick_torolegyet);
    connect(ui->pushButton_torolmindent, &QPushButton::clicked, this, &MainWindow::onButtonClick_torolmindent);
    connect(ui->pushButton_memoria, &QPushButton::clicked, this, &MainWindow::onButtonClick_memoria);

    connect(ui->plainTextEdit, &QPlainTextEdit::textChanged, this, &MainWindow::onPlainTextEditUpdate);

}

MainWindow::~MainWindow()
{
    eredmenyek.clear();
    delete ui;
}

void MainWindow::onButtonClick_0()
{
    Function("number", 0);
}

void MainWindow::onButtonClick_1()
{
    Function("number", 1);
}

void MainWindow::onButtonClick_2()
{
    Function("number", 2);
}

void MainWindow::onButtonClick_3()
{
    Function("number", 3);
}

void MainWindow::onButtonClick_4()
{
    Function("number", 4);
}

void MainWindow::onButtonClick_5()
{
    Function("number", 5);
}

void MainWindow::onButtonClick_6()
{
    Function("number", 6);
}

void MainWindow::onButtonClick_7()
{
    Function("number", 7);
}

void MainWindow::onButtonClick_8()
{
    Function("number", 8);
}

void MainWindow::onButtonClick_9()
{
    Function("number", 9);
}

void MainWindow::onButtonClick_egesz()
{
    Function("egesz");
}

void MainWindow::onButtonClick_egyenlo()
{
    Function("egyenlo");
}

void MainWindow::onButtonClick_plusz()
{
    Function("plusz");
}

void MainWindow::onButtonClick_minusz()
{
    Function("minusz");
}

void MainWindow::onButtonClick_szorzas()
{
    Function("szorzas");
}

void MainWindow::onButtonClick_osztas()
{
    Function("osztas");
}

void MainWindow::onButtonClick_torolegyet()
{
    Function("torolegyet");
}

void MainWindow::onButtonClick_torolmindent()
{
    Function("torolmindent");
}

void MainWindow::onButtonClick_memoria()
{
    Function("memoria");
}



void MainWindow::onPlainTextEditUpdate()
{
    QString editedText = ui->plainTextEdit->toPlainText();
    qDebug() << "Text edited:" << editedText;
}

void MainWindow::Function(QString type, int number)
{
    qDebug() << "Before edit:" << ui->plainTextEdit->toPlainText();

    if(type == "minusz"){

        if(ui->plainTextEdit->toPlainText().size() == 0 || MainWindow::ujra == "igen"){

            if(!ui->pushButton_egyenlo->isEnabled()){
                ui->plainTextEdit->setPlainText("");
                ui->pushButton_egyenlo->setDisabled(false);
                ui->pushButton_plusz->setDisabled(false);
                //ui->pushButton_minusz->setDisabled(false);
                ui->pushButton_szorzas->setDisabled(false);
                ui->pushButton_osztas->setDisabled(false);
                ui->pushButton_egesz->setDisabled(false);
                ui->pushButton_torolegyet->setDisabled(false);
                //ui->pushButton_0->setDisabled(false);
            }

            ui->plainTextEdit->insertPlainText("-");

        }

    }

    if(type == "number"){

        if(!ui->pushButton_egyenlo->isEnabled()){
            ui->plainTextEdit->setPlainText("");
            ui->pushButton_egyenlo->setDisabled(false);
            ui->pushButton_plusz->setDisabled(false);
            //ui->pushButton_minusz->setDisabled(false);
            ui->pushButton_szorzas->setDisabled(false);
            ui->pushButton_osztas->setDisabled(false);
            ui->pushButton_egesz->setDisabled(false);
            ui->pushButton_torolegyet->setDisabled(false);
            //ui->pushButton_0->setDisabled(false);
        }

        if(type == "number"){ // HA ELSŐNEK NULLÁKAT IRNA BE, HA MÉGEGY NULLÁT IR UTANA AKKOR NE IRJA, HA MÁS SZÁM LESZ A KÖVETKEZO AKKOR CSERELJE LE
            //qDebug() << "helo";
            QString jelenlegi = ui->plainTextEdit->toPlainText();
            if(ui->plainTextEdit->toPlainText().size() > 0 && ui->plainTextEdit->toPlainText().size() < 2 && QString(ui->plainTextEdit->toPlainText().back()) == "0"){
                qDebug() << "helo";
                jelenlegi.chop(1);
                ui->plainTextEdit->setPlainText("");
                //ui->plainTextEdit->insertPlainText(jelenlegi);
            }
        }

        if(type == "number"){
            //qDebug() << "helo";
            QString jelenlegi = ui->plainTextEdit->toPlainText();
            if(ui->plainTextEdit->toPlainText().size() > 0 && QString(ui->plainTextEdit->toPlainText().back()) == "0"){
                qDebug() << "hali";
                jelenlegi.chop(1);
                if(jelenlegi.size() > 0){
                    if(QString(jelenlegi.back()) == "+" || QString(jelenlegi.back()) == "*" || QString(jelenlegi.back()) == "/" || QString(jelenlegi.back()) == "-"){
                        ui->plainTextEdit->setPlainText("");
                        ui->plainTextEdit->insertPlainText(jelenlegi);
                    }
                }
            }
        }

        ui->plainTextEdit->insertPlainText(QString::number(number));
        //qDebug() << ui->plainTextEdit->toPlainText().size();
    }

    if(type == "plusz"){
        if((ui->plainTextEdit->toPlainText().back()).isDigit()){
            ui->plainTextEdit->insertPlainText("+");
        }

    } else if(type == "minusz"){
        if((ui->plainTextEdit->toPlainText().back()).isDigit()){
            ui->plainTextEdit->insertPlainText("-");
        }

    } else if(type == "szorzas"){
        if((ui->plainTextEdit->toPlainText().back()).isDigit()){
            ui->plainTextEdit->insertPlainText("*");
        }

    } else if(type == "osztas"){
        if((ui->plainTextEdit->toPlainText().back()).isDigit()){
            ui->plainTextEdit->insertPlainText("/");
        }

    } else if(type == "egesz"){
        if((ui->plainTextEdit->toPlainText().back()).isDigit()){
            ui->plainTextEdit->insertPlainText(".");
        }

    } else if(type == "memoria"){
        if(ui->memoria->isVisible()){
            ui->memoria->hide();
        } else {
            ui->memoria->show();
        }

    } else if(type == "egyenlo"){
        QJSEngine engine;
        QJSValue result = engine.evaluate(ui->plainTextEdit->toPlainText());

        if(result.isError()){
            QMessageBox::warning(this, "Hiba", "A megadott elemekben hiba van");

        } else {

            ui->pushButton_egyenlo->setDisabled(true);
            ui->pushButton_plusz->setDisabled(true);
            //ui->pushButton_minusz->setDisabled(true);
            ui->pushButton_szorzas->setDisabled(true);
            ui->pushButton_osztas->setDisabled(true);
            ui->pushButton_egesz->setDisabled(true);
            ui->pushButton_torolegyet->setDisabled(true);
            //ui->pushButton_0->setDisabled(true);

            ui->plainTextEdit->insertPlainText("=");
            ui->plainTextEdit->insertPlainText(result.toString());

            MainWindow::eredmenyek.append(ui->plainTextEdit->toPlainText());

            ui->memoria->appendPlainText(ui->plainTextEdit->toPlainText());

            ujra = "igen";
        }

    } else if(type == "torolmindent"){

        ui->plainTextEdit->setPlainText("");

        if(ui->plainTextEdit->toPlainText() == ""){
            ui->pushButton_egyenlo->setDisabled(true);
            ui->pushButton_plusz->setDisabled(true);
            //ui->pushButton_minusz->setDisabled(true);
            ui->pushButton_szorzas->setDisabled(true);
            ui->pushButton_osztas->setDisabled(true);
            ui->pushButton_egesz->setDisabled(true);
            ui->pushButton_torolegyet->setDisabled(true);
            //ui->pushButton_0->setDisabled(true);
        }

    } else if(type == "torolegyet"){
        QString jelenlegi = ui->plainTextEdit->toPlainText();
        if(ui->plainTextEdit->toPlainText() == ""){
            ui->pushButton_egyenlo->setDisabled(true);
            ui->pushButton_plusz->setDisabled(true);
            //ui->pushButton_minusz->setDisabled(true);
            ui->pushButton_szorzas->setDisabled(true);
            ui->pushButton_osztas->setDisabled(true);
            ui->pushButton_egesz->setDisabled(true);
            ui->pushButton_torolegyet->setDisabled(true);
            //ui->pushButton_0->setDisabled(true);
        } else{
            jelenlegi.chop(1);
            if(jelenlegi == ""){
                ui->pushButton_egyenlo->setDisabled(true);
                ui->pushButton_plusz->setDisabled(true);
                //ui->pushButton_minusz->setDisabled(true);
                ui->pushButton_szorzas->setDisabled(true);
                ui->pushButton_osztas->setDisabled(true);
                ui->pushButton_egesz->setDisabled(true);
                ui->pushButton_torolegyet->setDisabled(true);
                //ui->pushButton_0->setDisabled(true);
            }
        }
        ui->plainTextEdit->setPlainText("");
        ui->plainTextEdit->insertPlainText(jelenlegi);
    }

}
