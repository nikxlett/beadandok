#ifndef MAINWINDOW_H
#define MAINWINDOW_H

#include <QMainWindow>

QT_BEGIN_NAMESPACE
namespace Ui { class MainWindow; }
QT_END_NAMESPACE

class MainWindow : public QMainWindow
{
    Q_OBJECT

public:
    QString ujra = "nem";
    MainWindow(QWidget *parent = nullptr);
    ~MainWindow();

private slots:
    void onButtonClick_0();
    void onButtonClick_1();
    void onButtonClick_2();
    void onButtonClick_3();
    void onButtonClick_4();
    void onButtonClick_5();
    void onButtonClick_6();
    void onButtonClick_7();
    void onButtonClick_8();
    void onButtonClick_9();

    void onButtonClick_egesz();
    void onButtonClick_egyenlo();
    void onButtonClick_plusz();
    void onButtonClick_minusz();
    void onButtonClick_szorzas();
    void onButtonClick_osztas();
    void onButtonClick_torolegyet();
    void onButtonClick_torolmindent();
    void onButtonClick_memoria();

    void onPlainTextEditUpdate();
    void Function(QString type, int number = 0);

private:
    QList<QString> eredmenyek;
    Ui::MainWindow *ui;
};
#endif // MAINWINDOW_H
