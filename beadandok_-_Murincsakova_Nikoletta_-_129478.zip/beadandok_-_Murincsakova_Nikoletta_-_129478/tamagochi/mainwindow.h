#ifndef MAINWINDOW_H
#define MAINWINDOW_H

#include <QMainWindow>
#include <QObject>
#include <QTimer>
#include <qcoreevent.h>>


QT_BEGIN_NAMESPACE
namespace Ui {
class MainWindow;
}
QT_END_NAMESPACE

namespace Colors {
    const QColor SimaZold(126, 164, 122, 255);
    const QColor SotetZold(99, 134, 96, 255);
}

namespace AllapotLista {
    const QString szomoru = "szomoru";
    const QString ehes = "ehes";
    const QString almos = "almos";
    const QString boldog = "boldog";
    const QString elpirult = "elpirult";
    const QString nyugodt = "nyugodt";
    const QString alszik = "alszik";
    const QString eszik = "eszik";
}

class tamagochi : public QMainWindow
{
    Q_OBJECT

public:
    tamagochi(QWidget *parent = nullptr);
    explicit tamagochi(Ui::MainWindow *ui) : ui(ui) {}
    ~tamagochi();
    void mouseMoveEvent(QMouseEvent *ev);
    void mousePressEvent(QMouseEvent *ev);
    void etetes();
    void lampa();
    bool lampa_kapcs = true;
    void mouseReleaseEvent(QMouseEvent *ev);
    void statuszEllenorzes();
    QColor getPixelColor(QMouseEvent *ev);
    void effektTorles();


public slots:
    void boldogsag_Function();
    void ehseg_Function();
    void almossag_Function();

private:
    QString allapot;
    Ui::MainWindow *ui;
    QTimer *boldogsag_timer;
    QTimer *ehseg_timer;
    QTimer *almossag_timer;
    bool balEgerGombTart = false;
};

#endif // MAINWINDOW_H
