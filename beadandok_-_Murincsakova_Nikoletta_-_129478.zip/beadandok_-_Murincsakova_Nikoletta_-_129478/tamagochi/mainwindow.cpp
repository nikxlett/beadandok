#include "mainwindow.h"
#include "ui_mainwindow.h"
#include <QLabel>
#include <QPixmap>
#include <QSignalMapper>

#include <QGraphicsView>
#include <QGraphicsPixmapItem>
#include <QMouseEvent>
#include <QThread>


tamagochi::tamagochi(QWidget *parent)
    : QMainWindow(parent)
    , ui(new Ui::MainWindow)
{
    ui->setupUi(this);
    this->setMouseTracking(true);
    ui->centralwidget->setMouseTracking(true);
    ui->frame->setMouseTracking(true);
    QPixmap img(":/images/boldog.png");
    ui->kep->setPixmap(img.scaled(500,700,Qt::KeepAspectRatio));
    ui->kep->setScaledContents( true );
    ui->kep->setSizePolicy( QSizePolicy::Ignored, QSizePolicy::Ignored );
    ui->kep->setStyleSheet("background-color: rgba(255, 255, 255, 0);");
    ui->kep->setMouseTracking(true);

    QPixmap hatter(":/images/hatter.png");
    ui->kep_hatter->setPixmap(hatter.scaled(1000,1000,Qt::KeepAspectRatio));
    ui->kep_hatter->setScaledContents( true );
    ui->kep_hatter->setMouseTracking(true);

    QPixmap szemek(":/images/szem.png");
    ui->kep_szem->setPixmap(szemek.scaled(1000,1000,Qt::KeepAspectRatio));
    ui->kep_szem->setScaledContents( true );
    ui->kep_szem->setMouseTracking(true);
        // ui->kep_szem->setSizePolicy( QSizePolicy::Ignored, QSizePolicy::Ignored );

    boldogsag_timer = new QTimer(this);
    ehseg_timer = new QTimer(this);
    almossag_timer = new QTimer(this);
    connect(boldogsag_timer, SIGNAL(timeout()), this, SLOT(boldogsag_Function()));
    connect(ehseg_timer, SIGNAL(timeout()), this, SLOT(ehseg_Function()));
    connect(almossag_timer, SIGNAL(timeout()), this, SLOT(almossag_Function()));

    boldogsag_timer->start(2000);
    ehseg_timer->start(4000);
    almossag_timer->start(6000);

    connect(ui->pushButton_kaja,  &QPushButton::clicked, this, &tamagochi::etetes);
    connect(ui->pushButton_lampa,  &QPushButton::clicked, this, &tamagochi::lampa);

    ui->pushButton_kaja->setIcon(QIcon(":/images/kaja.png"));
    ui->pushButton_kaja->setIconSize(QSize(85, 85));

    ui->pushButton_lampa->setIcon(QIcon(":/images/lampa-fel.png"));
    ui->pushButton_lampa->setIconSize(QSize(85, 85));

    lampa_kapcs = true;

    ui->sotetseg->setVisible(false);
}



tamagochi::~tamagochi()
{
    delete ui;
}

void tamagochi::etetes(){
    if( tamagochi::allapot == AllapotLista::alszik){
        return;
    }
    tamagochi::allapot = AllapotLista::eszik;

    if(tamagochi::allapot == AllapotLista::eszik){
        QPixmap img(":/images/eszik.png");
        ui->kep->setPixmap(img.scaled(500,700,Qt::KeepAspectRatio));
        ui->kep->setScaledContents( true );
        //
    }
    //
    if(tamagochi::allapot.size() > 1){
        QTimer::singleShot(1000, this, tamagochi::effektTorles);
    }

    ui->boldogsag_Bar->setValue(ui->boldogsag_Bar->value() + 1);
    ui->ehseg_Bar->setValue(ui->ehseg_Bar->value() + 5);
}

void tamagochi::lampa(){
    if(lampa_kapcs == true){
        lampa_kapcs = false;
        ui->sotetseg->setVisible(true);
        this->setStyleSheet("background-color: rgb(162, 162, 162);");

        tamagochi::allapot = AllapotLista::alszik;
        QPixmap img(":/images/alszik.png");
        ui->kep->setPixmap(img.scaled(500,700,Qt::KeepAspectRatio));

        ui->pushButton_lampa->setIcon(QIcon(":/images/lampa-le.png"));
        ui->pushButton_lampa->setIconSize(QSize(85, 85));

    } else if(lampa_kapcs == false){
        lampa_kapcs = true;
        ui->sotetseg->setVisible(false);
        this->setStyleSheet("background-color: rgb(186, 186, 186);");

        ui->pushButton_lampa->setIcon(QIcon(":/images/lampa-fel.png"));
        ui->pushButton_lampa->setIconSize(QSize(85, 85));
        tamagochi::allapot = "";
        statuszEllenorzes();
    }
}

void tamagochi::mouseMoveEvent(QMouseEvent *ev)
{
    QPoint egerpoz = ev->pos();
    double xpoz = egerpoz.x() - 395;
    double ypoz = egerpoz.y() - 330;

    double osztoX = 40;
    double osztoY = 20;
    double kovetkezo_X = 0+(xpoz/osztoX);
    double kovetkezo_Y = -7.6+(ypoz/osztoY);

    if((kovetkezo_X <= 12 && kovetkezo_X >= -10) && (kovetkezo_Y <= 6 && kovetkezo_Y >= -26)){
        osztoX = 40;
        osztoY = 20;
    } else if((kovetkezo_X <= 15 && kovetkezo_X >= -10) && (kovetkezo_Y <= 8 && kovetkezo_Y >= -30)){
        osztoX = 50;
        osztoY = 30;
    } else if((kovetkezo_X <= 18 && kovetkezo_X >= -14) && (kovetkezo_Y <= 10 && kovetkezo_Y >= -35)){
        osztoX = 70;
        osztoY = 40;
    } else {
        if((kovetkezo_X <= 12 && kovetkezo_X >= -14) && (kovetkezo_Y <= 10 && kovetkezo_Y >= -35)){
            osztoX = 90;
            osztoY = 50;
        } else {
            osztoX = 110;
            osztoY = 60;
        }
    }
    ui->kep_szem->move(0+(xpoz/osztoX), -7.6+(ypoz/osztoY));

    QColor color = tamagochi::getPixelColor(ev);
    if(((color.red() == Colors::SimaZold.red() && color.green() == Colors::SimaZold.green() && color.blue() == Colors::SimaZold.blue()) ||
         (color.red() == Colors::SotetZold.red() && color.green() == Colors::SotetZold.green() && color.blue() == Colors::SotetZold.blue()))
        && tamagochi::balEgerGombTart){

        if( tamagochi::allapot == AllapotLista::alszik){
            return;
        }

        tamagochi::allapot = AllapotLista::nyugodt;

        QPixmap img(":/images/nyugodt.png");
        ui->kep->setPixmap(img.scaled(500,700,Qt::KeepAspectRatio));
        ui->kep->setScaledContents( true );
        ui->boldogsag_Bar->setValue(ui->boldogsag_Bar->value() + 2);
    }
}

void tamagochi::mousePressEvent(QMouseEvent *ev)
{
    tamagochi::balEgerGombTart = true;
    QColor color = tamagochi::getPixelColor(ev);
    if(((color.red() == Colors::SimaZold.red() && color.green() == Colors::SimaZold.green() && color.blue() == Colors::SimaZold.blue()) ||
         (color.red() == Colors::SotetZold.red() && color.green() == Colors::SotetZold.green() && color.blue() == Colors::SotetZold.blue()))
        && tamagochi::balEgerGombTart){

        if( tamagochi::allapot == AllapotLista::alszik){
            return;
        }

        tamagochi::allapot = AllapotLista::elpirult;
    }
}

void tamagochi::mouseReleaseEvent(QMouseEvent *ev)
{
    tamagochi::balEgerGombTart = false;

    if( tamagochi::allapot == AllapotLista::alszik){
        return;
    }

    if(tamagochi::allapot == AllapotLista::elpirult){
        QPixmap img(":/images/elpirult.png");
        ui->kep->setPixmap(img.scaled(500,700,Qt::KeepAspectRatio));
        ui->kep->setScaledContents( true );
        ui->boldogsag_Bar->setValue(ui->boldogsag_Bar->value() + 2);
    }

    if(tamagochi::allapot.size() > 1){
        QTimer::singleShot(1000, this, tamagochi::effektTorles);
    }
}


void tamagochi::boldogsag_Function(){
    statuszEllenorzes();
    ui->boldogsag_Bar->setValue(ui->boldogsag_Bar->value() - 1);

}

void tamagochi::ehseg_Function()
{
    ui->ehseg_Bar->setValue(ui->ehseg_Bar->value() - 1);
}

void tamagochi::almossag_Function()
{
    ui->almos_Bar->setValue(ui->almos_Bar->value() - 1);
}

void tamagochi::statuszEllenorzes(){
    if(tamagochi::allapot.size() > 1){
         if(tamagochi::allapot == AllapotLista::elpirult || tamagochi::allapot == AllapotLista::alszik || tamagochi::allapot == AllapotLista::nyugodt){
            if(tamagochi::allapot == AllapotLista::alszik){
                QPixmap img(":/images/alszik.png");
                ui->kep->setPixmap(img.scaled(500,700,Qt::KeepAspectRatio));

                ui->almos_Bar->setValue(ui->almos_Bar->value() + 5);

            } else if(tamagochi::allapot == AllapotLista::elpirult){
                QPixmap img(":/images/elpirult.png");
                ui->kep->setPixmap(img.scaled(500,700,Qt::KeepAspectRatio));

            }  else if(tamagochi::allapot == AllapotLista::nyugodt){
                QPixmap img(":/images/nyugodt.png");
                ui->kep->setPixmap(img.scaled(500,700,Qt::KeepAspectRatio));
            }
            return;
         }
    }



    if(ui->boldogsag_Bar->value() >= 30){
        if(ui->ehseg_Bar->value() >= 30){
            if(ui->almos_Bar->value() >= 30){
                tamagochi::allapot = AllapotLista::boldog;
                QPixmap img(":/images/boldog.png");
                ui->kep->setPixmap(img.scaled(500,700,Qt::KeepAspectRatio));
            } else {
                tamagochi::allapot = AllapotLista::almos;
                QPixmap img(":/images/almos.png");
                ui->kep->setPixmap(img.scaled(500,700,Qt::KeepAspectRatio));
            }
        } else {
            tamagochi::allapot = AllapotLista::ehes;
            QPixmap img(":/images/ehes.png");
            ui->kep->setPixmap(img.scaled(500,700,Qt::KeepAspectRatio));
        }
    } else {
        tamagochi::allapot = AllapotLista::szomoru;
        QPixmap img(":/images/szomoru.png");
        ui->kep->setPixmap(img.scaled(500,700,Qt::KeepAspectRatio));
    }
}

QColor tamagochi::getPixelColor(QMouseEvent *ev){
    QScreen *screen = QGuiApplication::screenAt(mapToGlobal(ev->pos()));

    if (!screen)
        return false;

    QPoint egerPoz = QCursor::pos();

    QPixmap pixmap = screen->grabWindow(0, egerPoz.x(), egerPoz.y(), 1, 1);


    return pixmap.toImage().pixelColor(0, 0);
}

void tamagochi::effektTorles(){
    tamagochi::allapot = "";
    tamagochi::statuszEllenorzes();
}
